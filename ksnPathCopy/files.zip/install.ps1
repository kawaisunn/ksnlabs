<#
.SYNOPSIS
    Install ksnPathCopy context menu utility.
.DESCRIPTION
    Deploys ksnPathCopy.ps1 to a permanent location and registers a cascading
    right-click context menu in Windows Explorer for files, folders, and
    folder backgrounds.

    Menu structure:
      ksnPathCopy  →  Path Copy (quoted, mapped)     ← default / bold
                      Path (unquoted, mapped)
                      ──────────────────────
                      UNC Path (server name)
                      UNC Raw Path (IP, direct)

    v1.1: Calls PowerShell directly (no VBS launcher) for compatibility
    with environments where Windows Script Host is disabled by endpoint
    protection (e.g., Sophos).

.PARAMETER InstallDir
    Where to install the scripts. Default: C:\Program Files\ksnPathCopy
.PARAMETER Uninstall
    Remove all registry entries and optionally delete installed files.
.NOTES
    Author:  kawaisunn / ksnlabs
    Version: 1.1.0
    Date:    2026-03-11
    Requires: Run as Administrator
#>

param(
    [string]$InstallDir = "$env:ProgramFiles\ksnPathCopy",
    [switch]$Uninstall
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ── Elevation check ──────────────────────────────────────────────────
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
            ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "ERROR: This script requires Administrator privileges." -ForegroundColor Red
    Write-Host "Right-click PowerShell → Run as Administrator, then re-run." -ForegroundColor Yellow
    exit 1
}

# ── Constants ────────────────────────────────────────────────────────
$appName      = "ksnPathCopy"
$version      = "1.1.0"
$commandStore = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell"

# Resolve pwsh vs powershell — prefer pwsh (PowerShell Core)
$psExe = (Get-Command pwsh -ErrorAction SilentlyContinue)?.Source
if (-not $psExe) {
    $psExe = (Get-Command powershell.exe -ErrorAction SilentlyContinue)?.Source
}
if (-not $psExe) {
    $psExe = "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"
}
Write-Host "  Using shell: $psExe" -ForegroundColor Gray

# The four modes and their display labels
$modes = [ordered]@{
    PathCopy = @{ Label = "Path Copy (quoted, mapped)";  Icon = "imageres.dll,3" }
    Path     = @{ Label = "Path (unquoted, mapped)";     Icon = "imageres.dll,3" }
    UNCPath  = @{ Label = "UNC Path (server name)";      Icon = "shell32.dll,275" }
    UNCRaw   = @{ Label = "UNC Raw Path (IP, direct)";   Icon = "shell32.dll,18" }
}

# Context menu registry roots
$menuRoots = @(
    "HKCR:\*\shell\$appName",
    "HKCR:\Directory\shell\$appName",
    "HKCR:\Directory\Background\shell\$appName"
)

# Ensure HKCR: PSDrive exists
if (-not (Test-Path "HKCR:\")) {
    New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT -Scope Script | Out-Null
}

# ── Helper: build the command string for a given mode + path var ─────
function Get-CmdString {
    param([string]$PathVar, [string]$ModeName)
    $scriptPath = Join-Path $InstallDir "ksnPathCopy.ps1"
    return "$psExe -NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$scriptPath`" -TargetPath `"$PathVar`" -Mode $ModeName"
}

# ── UNINSTALL ────────────────────────────────────────────────────────
if ($Uninstall) {
    Write-Host "`n  ksnPathCopy Uninstall" -ForegroundColor Cyan
    Write-Host "  $('─' * 40)" -ForegroundColor DarkGray

    $allKeys = @()
    foreach ($mode in $modes.Keys) {
        $allKeys += "${appName}.$mode"
        $allKeys += "${appName}.bg_$mode"
    }
    $allKeys += "${appName}.Sep1"
    $allKeys += "${appName}.bg_Sep1"

    foreach ($key in $allKeys) {
        $regPath = "$commandStore\$key"
        if (Test-Path $regPath) {
            Remove-Item $regPath -Recurse -Force
            Write-Host "  [OK] Removed CommandStore: $key" -ForegroundColor Green
        }
    }

    foreach ($root in $menuRoots) {
        if (Test-Path $root) {
            Remove-Item $root -Recurse -Force
            Write-Host "  [OK] Removed menu: $root" -ForegroundColor Green
        }
    }

    if (Test-Path $InstallDir) {
        $confirm = Read-Host "  Delete installed files at ${InstallDir}? (y/n)"
        if ($confirm -eq 'y') {
            Remove-Item $InstallDir -Recurse -Force
            Write-Host "  [OK] Deleted $InstallDir" -ForegroundColor Green
        } else {
            Write-Host "  [--] Files kept at $InstallDir" -ForegroundColor Yellow
        }
    }

    Write-Host "`n  Uninstall complete. Restart Explorer or log off to clear menu cache.`n" -ForegroundColor Cyan
    exit 0
}

# ── INSTALL ──────────────────────────────────────────────────────────
Write-Host ""
Write-Host "  ┌─────────────────────────────────────────┐" -ForegroundColor Cyan
Write-Host "  │      ksnPathCopy v$version  Installer       │" -ForegroundColor Cyan
Write-Host "  │      kawaisunn / ksnlabs                 │" -ForegroundColor Cyan
Write-Host "  │      Direct PowerShell — no VBS/WSH      │" -ForegroundColor Cyan
Write-Host "  └─────────────────────────────────────────┘" -ForegroundColor Cyan
Write-Host ""

# ── Step 1: Deploy files ─────────────────────────────────────────────
Write-Host "  [1/3] Deploying files → $InstallDir" -ForegroundColor Yellow

if (-not (Test-Path $InstallDir)) {
    New-Item -Path $InstallDir -ItemType Directory -Force | Out-Null
}

$sourceDir = $PSScriptRoot
if (-not $sourceDir) { $sourceDir = Split-Path -Parent $MyInvocation.MyCommand.Path }
if (-not $sourceDir) { $sourceDir = Get-Location }

foreach ($file in @("ksnPathCopy.ps1", "install.ps1")) {
    $src = Join-Path $sourceDir $file
    $dst = Join-Path $InstallDir $file
    if (Test-Path $src) {
        Copy-Item $src $dst -Force
        Write-Host "    Deployed: $file" -ForegroundColor Green
    } elseif ($file -eq "ksnPathCopy.ps1") {
        Write-Host "    ERROR: Cannot find $file in $sourceDir" -ForegroundColor Red
        exit 1
    }
}

$psExe | Set-Content (Join-Path $InstallDir ".shell_path") -Encoding UTF8
Write-Host "    Recorded shell: $psExe" -ForegroundColor Green

# ── Step 2: Register CommandStore entries ─────────────────────────────
Write-Host "`n  [2/3] Registering CommandStore entries" -ForegroundColor Yellow

$isFirst = $true
foreach ($entry in $modes.GetEnumerator()) {
    $modeName  = $entry.Key
    $modeLabel = $entry.Value.Label
    $modeIcon  = $entry.Value.Icon

    # Standard entry (files + folders: %1)
    $regPath = "$commandStore\${appName}.${modeName}"
    New-Item -Path $regPath -Force | Out-Null
    Set-ItemProperty -Path $regPath -Name "(Default)" -Value $modeLabel
    Set-ItemProperty -Path $regPath -Name "Icon" -Value $modeIcon
    if ($isFirst) {
        Set-ItemProperty -Path $regPath -Name "CommandFlags" -Value 0x00000020 -Type DWord
        $isFirst = $false
    }
    $cmdPath = "$regPath\command"
    New-Item -Path $cmdPath -Force | Out-Null
    Set-ItemProperty -Path $cmdPath -Name "(Default)" -Value (Get-CmdString '%1' $modeName)
    Write-Host "    Registered: ${appName}.${modeName}" -ForegroundColor Green

    # Background entry (folder background: %V)
    $bgRegPath = "$commandStore\${appName}.bg_${modeName}"
    New-Item -Path $bgRegPath -Force | Out-Null
    Set-ItemProperty -Path $bgRegPath -Name "(Default)" -Value $modeLabel
    Set-ItemProperty -Path $bgRegPath -Name "Icon" -Value $modeIcon
    $bgCmdPath = "$bgRegPath\command"
    New-Item -Path $bgCmdPath -Force | Out-Null
    Set-ItemProperty -Path $bgCmdPath -Name "(Default)" -Value (Get-CmdString '%V' $modeName)
    Write-Host "    Registered: ${appName}.bg_${modeName}" -ForegroundColor Green
}

# Visual separators
foreach ($prefix in @("", "bg_")) {
    $sepPath = "$commandStore\${appName}.${prefix}Sep1"
    New-Item -Path $sepPath -Force | Out-Null
    Set-ItemProperty -Path $sepPath -Name "(Default)" -Value ""
    Set-ItemProperty -Path $sepPath -Name "CommandFlags" -Value 0x00000040 -Type DWord
}

$stdSubCmds = "${appName}.PathCopy;${appName}.Path;${appName}.Sep1;${appName}.UNCPath;${appName}.UNCRaw"
$bgSubCmds  = "${appName}.bg_PathCopy;${appName}.bg_Path;${appName}.bg_Sep1;${appName}.bg_UNCPath;${appName}.bg_UNCRaw"

# ── Step 3: Register context menu entries ─────────────────────────────
Write-Host "`n  [3/3] Registering context menus" -ForegroundColor Yellow

foreach ($root in $menuRoots) {
    $isBackground = $root -like '*Background*'
    New-Item -Path $root -Force | Out-Null
    Set-ItemProperty -Path $root -Name "(Default)" -Value $appName
    Set-ItemProperty -Path $root -Name "Icon" -Value "imageres.dll,3"
    Set-ItemProperty -Path $root -Name "SubCommands" -Value $(if ($isBackground) { $bgSubCmds } else { $stdSubCmds })

    $menuType = if ($isBackground) { "Directory Background" }
                elseif ($root -like '*Directory*') { "Folders" }
                else { "Files" }
    Write-Host "    Registered: $menuType" -ForegroundColor Green
}

# ── Done ──────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "  ┌─────────────────────────────────────────┐" -ForegroundColor Green
Write-Host "  │         Installation Complete            │" -ForegroundColor Green
Write-Host "  └─────────────────────────────────────────┘" -ForegroundColor Green
Write-Host ""
Write-Host "  Files:    $InstallDir" -ForegroundColor White
Write-Host "  Shell:    $psExe" -ForegroundColor White
Write-Host "  Launcher: Direct PowerShell (no VBS/WSH)" -ForegroundColor White
Write-Host "  Menu:     Right-click any file, folder, or folder background" -ForegroundColor White
Write-Host ""
Write-Host "  Submenu:" -ForegroundColor Gray
Write-Host "    Path Copy    `"J:\District1\Top 40 Sites\Br0002c`"" -ForegroundColor Gray
Write-Host "    Path          J:\District1\Top 40 Sites\Br0002c" -ForegroundColor Gray
Write-Host "    ─────────────────────────────────────" -ForegroundColor DarkGray
Write-Host "    UNC Path      \\IGS-Rift\Share\District1\Top 40 Sites\Br0002c" -ForegroundColor Gray
Write-Host "    UNC Raw       \\10.1.2.3\Share\District1\Top 40 Sites\Br0002c" -ForegroundColor Gray
Write-Host ""
Write-Host "  To uninstall:  .\install.ps1 -Uninstall" -ForegroundColor DarkGray
Write-Host "  Explorer may need restart: taskkill /f /im explorer.exe; explorer" -ForegroundColor DarkGray
Write-Host ""
