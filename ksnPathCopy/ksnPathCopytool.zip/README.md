# ksnPathCopy v1.0.0

**Windows Explorer context menu utility for copying file/folder paths in multiple formats.**

Designed for state agency networks with mapped drives, DFS namespaces, and mixed UNC/drive-letter environments.

## What It Does

Right-click any file, folder, or folder background in Explorer → **ksnPathCopy** submenu with four copy modes:

| Mode | Example Output | Use Case |
|------|---------------|----------|
| **Path Copy** | `"J:\District1\Top 40 Sites\Br0002c"` | Pasting into scripts, terminals, documentation (safe with spaces) |
| **Path** | `J:\District1\Top 40 Sites\Br0002c` | Clean path for file dialogs, search bars |
| **UNC Path** | `\\IGS-Rift\Share\District1\Top 40 Sites\Br0002c` | Cross-machine references using server hostname |
| **UNC Raw** | `\\10.1.2.3\Share\District1\Top 40 Sites\Br0002c` | Direct IP path — bypasses DNS/DFS, maximum portability |

## Components

All native Windows — **zero third-party dependencies**.

| File | Purpose |
|------|---------|
| `ksnPathCopy.ps1` | Core path resolution logic (PowerShell 5.1+) |
| `ksnPathCopy.vbs` | Invisible launcher — prevents console window flash |
| `install.ps1` | Deployment script — copies files + registers context menu |

## Installation

```powershell
# Run as Administrator
powershell -ExecutionPolicy Bypass -File install.ps1

# Custom install location (default: C:\Program Files\ksnPathCopy)
powershell -ExecutionPolicy Bypass -File install.ps1 -InstallDir "D:\Tools\ksnPathCopy"
```

## Uninstallation

```powershell
# Run as Administrator — removes all registry entries, optionally deletes files
powershell -ExecutionPolicy Bypass -File install.ps1 -Uninstall
```

## Registry Changes (for IT/Security Review)

The installer creates the following registry entries. **No system files are modified.** All entries are removable via the `-Uninstall` flag.

### CommandStore Entries (HKLM)

These define the submenu commands:

```
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\
  ksnPathCopy.PathCopy\         (Default) = "Path Copy (quoted, mapped)"
    command\                    (Default) = wscript.exe "<InstallDir>\ksnPathCopy.vbs" "%1" PathCopy
  ksnPathCopy.Path\             (Default) = "Path (unquoted, mapped)"
    command\                    (Default) = wscript.exe "<InstallDir>\ksnPathCopy.vbs" "%1" Path
  ksnPathCopy.Sep1\             (Default) = ""     [visual separator, CommandFlags=0x40]
  ksnPathCopy.UNCPath\          (Default) = "UNC Path (server name)"
    command\                    (Default) = wscript.exe "<InstallDir>\ksnPathCopy.vbs" "%1" UNCPath
  ksnPathCopy.UNCRaw\           (Default) = "UNC Raw Path (IP, direct)"
    command\                    (Default) = wscript.exe "<InstallDir>\ksnPathCopy.vbs" "%1" UNCRaw
```

Parallel `bg_*` entries exist for Directory Background context (using `%V` instead of `%1`).

### Context Menu Entries (HKCR)

These attach the submenu to Explorer's right-click menu:

```
HKCR\*\shell\ksnPathCopy\                      (files)
  SubCommands = "ksnPathCopy.PathCopy;ksnPathCopy.Path;ksnPathCopy.Sep1;..."
HKCR\Directory\shell\ksnPathCopy\               (folders)
  SubCommands = "ksnPathCopy.PathCopy;ksnPathCopy.Path;ksnPathCopy.Sep1;..."
HKCR\Directory\Background\shell\ksnPathCopy\    (folder background)
  SubCommands = "ksnPathCopy.bg_PathCopy;ksnPathCopy.bg_Path;ksnPathCopy.bg_Sep1;..."
```

### Total Registry Footprint

- 14 CommandStore keys under HKLM (7 standard + 7 background variants)
- 3 context menu keys under HKCR
- No Run/RunOnce entries, no services, no scheduled tasks, no PATH modifications

## How Path Resolution Works

1. **Mapped drive detection**: Queries `Win32_LogicalDisk` (WMI) for network-mapped drives, falls back to parsing `net use` output. Also checks `subst` drives.

2. **UNC resolution**: For drive-letter paths, looks up the mapping table to find the UNC root, then appends the remainder. For local (non-mapped) drives, constructs an admin share path (`\\HOSTNAME\C$\...`).

3. **DFS resolution** (UNC Raw mode): Attempts `dfsutil` (available on Server editions) to resolve DFS namespace paths to their actual target servers. Falls through gracefully if unavailable.

4. **IP resolution** (UNC Raw mode): Resolves the server hostname to IPv4 via `[System.Net.Dns]::GetHostAddresses()`. Prefers IPv4 over IPv6. Returns hostname unchanged if DNS fails.

## Security Notes

- **No network calls** except DNS resolution (for UNC Raw mode only, and only to the local DNS server).
- **No data exfiltration** — the only output is to the Windows clipboard via `Set-Clipboard`.
- **No persistence** beyond registry entries (no services, tasks, or startup items).
- **Script is auditable** — PowerShell source is plain text, VBScript launcher is 15 lines.
- **Elevation required only for install/uninstall** — the context menu commands run as the logged-in user.

## Enterprise Deployment

### Group Policy (GPO)

1. Copy `ksnPathCopy.ps1` and `ksnPathCopy.vbs` to a network share (e.g., `\\DC\NETLOGON\Tools\ksnPathCopy\`).
2. Create a GPO Computer Startup Script that runs `install.ps1 -InstallDir "C:\Program Files\ksnPathCopy"`.
3. The install script is idempotent — safe to run on every boot.

### SCCM / Intune

Package the three files as an application with:
- Install command: `powershell.exe -ExecutionPolicy Bypass -File install.ps1`
- Uninstall command: `powershell.exe -ExecutionPolicy Bypass -File install.ps1 -Uninstall`
- Detection rule: Registry key exists at `HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\ksnPathCopy.PathCopy`

### Code Signing

For environments requiring signed scripts:

```powershell
$cert = Get-ChildItem Cert:\CurrentUser\My -CodeSigningCert | Select-Object -First 1
Set-AuthenticodeSignature -FilePath ksnPathCopy.ps1 -Certificate $cert
Set-AuthenticodeSignature -FilePath install.ps1 -Certificate $cert
```

## Future: Windows Store (MSIX)

The architecture is designed for eventual MSIX packaging:

1. Rewrite `ksnPathCopy.ps1` logic as a C# class library
2. Implement `IExplorerCommand` COM interface for native shell extension
3. Package as sparse MSIX with shell extension registration
4. Submit to Windows Store for state agency deployment via Intune

The current PowerShell implementation serves as the functional specification and test harness for the compiled version.

## Author

kawaisunn / ksnlabs — Idaho Geological Survey  
Created: 2026-03-11
