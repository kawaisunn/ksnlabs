' ksnPathCopy.vbs - Invisible launcher for ksnPathCopy.ps1
' Prevents PowerShell console flash when invoked from Explorer context menu.
' Usage: wscript ksnPathCopy.vbs "<path>" <Mode>
'
' Author:  kawaisunn / ksnlabs
' Version: 1.0.0
' Date:    2026-03-11

Dim installDir, targetPath, mode, psCmd

' Resolve install directory from this script's location
installDir = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\"))

' Arguments: (1) target path, (2) mode
If WScript.Arguments.Count < 1 Then
    WScript.Quit 1
End If

targetPath = WScript.Arguments(0)

If WScript.Arguments.Count >= 2 Then
    mode = WScript.Arguments(1)
Else
    mode = "PathCopy"
End If

' Escape single quotes in the path for PowerShell
targetPath = Replace(targetPath, "'", "''")

' Build PowerShell command
psCmd = "powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass " & _
        "-WindowStyle Hidden -File """ & installDir & "ksnPathCopy.ps1"" " & _
        "-TargetPath '" & targetPath & "' -Mode " & mode

' Run hidden (0 = hidden, False = don't wait)
CreateObject("WScript.Shell").Run psCmd, 0, False
