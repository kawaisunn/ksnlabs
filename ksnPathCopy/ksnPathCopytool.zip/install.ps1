<#
.SYNOPSIS
    Install ksnPathCopy context menu utility.
.DESCRIPTION
    Deploys ksnPathCopy.ps1 and ksnPathCopy.vbs to a permanent location and
    registers a cascading right-click context menu in Windows Explorer for
    files, folders, and folder backgrounds.

    Menu structure:
      ksnPathCopy  →  Path Copy (quoted, mapped)     ← default / bold
                      Path (unquoted, mapped)
                      ──────────────────────
                      UNC Path (server name)
                      UNC Raw Path (IP, direct)

    Registry approach uses HKLM CommandStore for proper cascading submenu.
    No third-party dependencies — pure Windows native components.

.PARAMETER InstallDir
    Where to install the scripts. Default: C:\Program Files\ksnPathCopy
.PARAMETER Uninstall
    Remove all registry entries and optionally delete installed files.
.NOTES
    Author:  kawaisunn / ksnlabs
    Version: 1.0.0
    Date:    2026-03-11
    Requires: Run as Administrator
    Auditable: All registry paths documented in README.md
#>

param(
    [string]$InstallDir = "$env:ProgramFiles\ksnPathCopy",
    [switch]$Uninstall
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ── Elevation check ──────────────────────────────────────────────────
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
            ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "ERROR: This script requires Administrator privileges." -ForegroundColor Red
    Write-Host "Right-click PowerShell → Run as Administrator, then re-run." -ForegroundColor Yellow
    exit 1
}

# ── Constants ────────────────────────────────────────────────────────
$appName      = "ksnPathCopy"
$version      = "1.0.0"
$commandStore = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell"

# The four modes and their display labels
$modes = [ordered]@{
    PathCopy = @{ Label = "Path Copy (quoted, mapped)";  Icon = "imageres.dll,3" }
    Path     = @{ Label = "Path (unquoted, mapped)";     Icon = "imageres.dll,3" }
    UNCPath  = @{ Label = "UNC Path (server name)";      Icon = "shell32.dll,275" }
    UNCRaw   = @{ Label = "UNC Raw Path (IP, direct)";   Icon = "shell32.dll,18" }
}

$subCommands = ($modes.Keys | ForEach-Object { "${appName}.$_" }) -join ";"

# Context menu registry roots — files, folders, and directory background
$menuRoots = @(
    "HKCR:\*\shell\$appName",                    # Files
    "HKCR:\Directory\shell\$appName",             # Folders
    "HKCR:\Directory\Background\shell\$appName"   # Folder background (empty space)
)

# Ensure HKCR: PSDrive exists
if (-not (Test-Path "HKCR:\")) {
    New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT -Scope Script | Out-Null
}

# ── UNINSTALL ────────────────────────────────────────────────────────
if ($Uninstall) {
    Write-Host "`n  ksnPathCopy Uninstall" -ForegroundColor Cyan
    Write-Host "  $('─' * 40)" -ForegroundColor DarkGray

    # Remove CommandStore entries
    foreach ($mode in $modes.Keys) {
        $regPath = "$commandStore\${appName}.$mode"
        if (Test-Path $regPath) {
            Remove-Item $regPath -Recurse -Force
            Write-Host "  [OK] Removed CommandStore: ${appName}.$mode" -ForegroundColor Green
        }
    }

    # Remove context menu registrations
    foreach ($root in $menuRoots) {
        if (Test-Path $root) {
            Remove-Item $root -Recurse -Force
            Write-Host "  [OK] Removed menu: $root" -ForegroundColor Green
        }
    }

    # Ask about installed files
    if (Test-Path $InstallDir) {
        $confirm = Read-Host "  Delete installed files at ${InstallDir}? (y/n)"
        if ($confirm -eq 'y') {
            Remove-Item $InstallDir -Recurse -Force
            Write-Host "  [OK] Deleted $InstallDir" -ForegroundColor Green
        } else {
            Write-Host "  [--] Files kept at $InstallDir" -ForegroundColor Yellow
        }
    }

    Write-Host "`n  Uninstall complete. Restart Explorer or log off to clear menu cache.`n" -ForegroundColor Cyan
    exit 0
}

# ── INSTALL ──────────────────────────────────────────────────────────
Write-Host ""
Write-Host "  ┌─────────────────────────────────────────┐" -ForegroundColor Cyan
Write-Host "  │       ksnPathCopy v$version  Installer       │" -ForegroundColor Cyan
Write-Host "  │       kawaisunn / ksnlabs                │" -ForegroundColor Cyan
Write-Host "  └─────────────────────────────────────────┘" -ForegroundColor Cyan
Write-Host ""

# ── Step 1: Deploy files ─────────────────────────────────────────────
Write-Host "  [1/3] Deploying files → $InstallDir" -ForegroundColor Yellow

if (-not (Test-Path $InstallDir)) {
    New-Item -Path $InstallDir -ItemType Directory -Force | Out-Null
}

$sourceDir = $PSScriptRoot
if (-not $sourceDir) { $sourceDir = Split-Path -Parent $MyInvocation.MyCommand.Path }

$filesToCopy = @("ksnPathCopy.ps1", "ksnPathCopy.vbs")
foreach ($file in $filesToCopy) {
    $src = Join-Path $sourceDir $file
    $dst = Join-Path $InstallDir $file
    if (Test-Path $src) {
        Copy-Item $src $dst -Force
        Write-Host "    Deployed: $file" -ForegroundColor Green
    } else {
        Write-Host "    WARNING: $src not found — copying from current directory" -ForegroundColor Yellow
        $altSrc = Join-Path (Get-Location) $file
        if (Test-Path $altSrc) {
            Copy-Item $altSrc $dst -Force
            Write-Host "    Deployed: $file (from cwd)" -ForegroundColor Green
        } else {
            Write-Host "    ERROR: Cannot find $file" -ForegroundColor Red
            exit 1
        }
    }
}

# ── Step 2: Register CommandStore entries ─────────────────────────────
Write-Host "`n  [2/3] Registering CommandStore entries" -ForegroundColor Yellow

$vbsPath = Join-Path $InstallDir "ksnPathCopy.vbs"
$isFirst = $true

foreach ($entry in $modes.GetEnumerator()) {
    $modeName  = $entry.Key
    $modeLabel = $entry.Value.Label
    $modeIcon  = $entry.Value.Icon
    $regPath   = "$commandStore\${appName}.${modeName}"

    # Create the command key
    New-Item -Path $regPath -Force | Out-Null
    Set-ItemProperty -Path $regPath -Name "(Default)" -Value $modeLabel
    Set-ItemProperty -Path $regPath -Name "Icon" -Value $modeIcon

    # Bold the first entry (default action indicator)
    if ($isFirst) {
        Set-ItemProperty -Path $regPath -Name "CommandFlags" -Value 0x00000020 -Type DWord
        $isFirst = $false
    }

    # The command itself
    # For Background context, %V = current directory; for files/folders, %1 = selected item
    # We use %1 for file/folder and %V for background — but CommandStore command is shared.
    # Explorer passes %1 for *, Directory and %V for Background. We handle both via the
    # parent menu's invocation pattern. CommandStore commands receive the path as %1.
    $cmdPath = "$regPath\command"
    New-Item -Path $cmdPath -Force | Out-Null
    Set-ItemProperty -Path $cmdPath -Name "(Default)" `
        -Value "wscript.exe `"$vbsPath`" `"%1`" $modeName"

    Write-Host "    Registered: ${appName}.${modeName}" -ForegroundColor Green
}

# Add a separator between mapped-drive modes and UNC modes
# CommandStore doesn't support separators natively, but we can insert a
# disabled "---" entry as a visual separator
$sepPath = "$commandStore\${appName}.Sep1"
New-Item -Path $sepPath -Force | Out-Null
Set-ItemProperty -Path $sepPath -Name "(Default)" -Value ""
Set-ItemProperty -Path $sepPath -Name "CommandFlags" -Value 0x00000040 -Type DWord  # Disabled/separator

$subCommandsWithSep = "${appName}.PathCopy;${appName}.Path;${appName}.Sep1;${appName}.UNCPath;${appName}.UNCRaw"

# ── Step 3: Register context menu entries ─────────────────────────────
Write-Host "`n  [3/3] Registering context menus" -ForegroundColor Yellow

# Build the menu entries for files, directories, and directory backgrounds
foreach ($root in $menuRoots) {
    New-Item -Path $root -Force | Out-Null
    Set-ItemProperty -Path $root -Name "(Default)" -Value $appName
    Set-ItemProperty -Path $root -Name "Icon" -Value "imageres.dll,3"
    Set-ItemProperty -Path $root -Name "SubCommands" -Value $subCommandsWithSep

    # For Directory\Background, the path variable is %V not %1
    # We handle this by also registering background-specific CommandStore
    # entries — but actually Windows passes %1 correctly for CommandStore
    # subcommands even from Background context. Verified on Server 2022.

    $menuType = if ($root -like '*Background*') { "Directory Background" }
                elseif ($root -like '*Directory*') { "Folders" }
                else { "Files" }
    Write-Host "    Registered: $menuType" -ForegroundColor Green
}

# ── Fix Background context: %V path passthrough ──────────────────────
# Directory\Background passes %V (folder path), but CommandStore subcommands
# receive it as %1 automatically in most Windows versions. However, on some
# Server builds, we need explicit Background-specific commands.
# Create a parallel set of CommandStore entries that use %V explicitly.
$bgMenuPath = "HKCR:\Directory\Background\shell\$appName"
if (Test-Path $bgMenuPath) {
    # Override: for background, we create local subcommands under the menu key
    # that use %V instead of %1
    foreach ($entry in $modes.GetEnumerator()) {
        $modeName = $entry.Key
        $bgCmdPath = "$commandStore\${appName}.bg_${modeName}"
        New-Item -Path $bgCmdPath -Force | Out-Null
        Set-ItemProperty -Path $bgCmdPath -Name "(Default)" -Value $entry.Value.Label
        Set-ItemProperty -Path $bgCmdPath -Name "Icon" -Value $entry.Value.Icon

        $bgCmdExecPath = "$bgCmdPath\command"
        New-Item -Path $bgCmdExecPath -Force | Out-Null
        Set-ItemProperty -Path $bgCmdExecPath -Name "(Default)" `
            -Value "wscript.exe `"$vbsPath`" `"%V`" $modeName"
    }

    # Separator for background version
    $bgSepPath = "$commandStore\${appName}.bg_Sep1"
    New-Item -Path $bgSepPath -Force | Out-Null
    Set-ItemProperty -Path $bgSepPath -Name "(Default)" -Value ""
    Set-ItemProperty -Path $bgSepPath -Name "CommandFlags" -Value 0x00000040 -Type DWord

    $bgSubCmds = "${appName}.bg_PathCopy;${appName}.bg_Path;${appName}.bg_Sep1;${appName}.bg_UNCPath;${appName}.bg_UNCRaw"
    Set-ItemProperty -Path $bgMenuPath -Name "SubCommands" -Value $bgSubCmds
    Write-Host "    Patched: Background uses %V path variable" -ForegroundColor Green
}

# ── Done ──────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "  ┌─────────────────────────────────────────┐" -ForegroundColor Green
Write-Host "  │         Installation Complete            │" -ForegroundColor Green
Write-Host "  └─────────────────────────────────────────┘" -ForegroundColor Green
Write-Host ""
Write-Host "  Files:    $InstallDir" -ForegroundColor White
Write-Host "  Menu:     Right-click any file, folder, or folder background" -ForegroundColor White
Write-Host "  Default:  Path Copy (quoted, mapped drive letters)" -ForegroundColor White
Write-Host ""
Write-Host "  Submenu:" -ForegroundColor Gray
Write-Host "    Path Copy    `"J:\District1\Top 40 Sites\Br0002c`"" -ForegroundColor Gray
Write-Host "    Path          J:\District1\Top 40 Sites\Br0002c" -ForegroundColor Gray
Write-Host "    UNC Path      \\IGS-Rift\Share\District1\Top 40 Sites\Br0002c" -ForegroundColor Gray
Write-Host "    UNC Raw       \\10.1.2.3\Share\District1\Top 40 Sites\Br0002c" -ForegroundColor Gray
Write-Host ""
Write-Host "  To uninstall:  .\install.ps1 -Uninstall" -ForegroundColor DarkGray
Write-Host "  Explorer may need restart (taskkill /f /im explorer.exe && explorer)" -ForegroundColor DarkGray
Write-Host ""
